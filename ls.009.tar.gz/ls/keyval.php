<?php
//Content-type: application/xml
//Cache-control: no-cache
?>
<select xmlns="http://www.w3.org/1999/xhtml">
    <option value="1aaaa">111</option>
    <option value="2aabb">222</option>
    <option value="3bbcc">333</option>
</select>
