#!/bin/bash
mysqldump 1s -u admin -p > 1s.sql
